import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

// Asosiy App
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Profil Sahifasi',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.deepPurple,
        brightness: Brightness.light,
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.deepPurple,
        brightness: Brightness.dark,
      ),
      themeMode: ThemeMode.system,
      home: const StartPage(),
    );
  }
}

// Boshlang'ich Sahifa
class StartPage extends StatelessWidget {
  const StartPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.deepPurple, Colors.deepPurpleAccent],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const CircleAvatar(
                radius: 60,
                backgroundImage: AssetImage('lib/image/cvn.jpg'),
              ),
              const SizedBox(height: 20),
              const Text(
                "Turg‘unboyev Nazrullo",
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.2,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 30),
              ElevatedButton(
                onPressed: () {
                  Navigator.of(context).push(
                    PageRouteBuilder(
                      pageBuilder: (_, __, ___) => const ProfilePage(),
                      transitionsBuilder: (_, animation, __, child) {
                        return FadeTransition(
                          opacity: animation,
                          child: child,
                        );
                      },
                      transitionDuration: const Duration(milliseconds: 600),
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                  backgroundColor: Colors.white,
                  foregroundColor: Colors.deepPurple,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
                child: const Text(
                  'Rezyume',
                  style: TextStyle(fontSize: 18),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// Rezyume Sahifasi
class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: const Text('Rezyume'),
        centerTitle: true,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              Center(
                child: Column(
                  children: [
                    const CircleAvatar(
                      radius: 60,
                      backgroundImage: AssetImage('lib/image/cvn.jpg'),
                    ),
                    const SizedBox(height: 15),
                    const Text(
                      "Turg‘unboyev Nazrullo",
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                        color: Colors.deepPurple,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      'Grafik Dizayner',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.grey.shade600,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 30),
              _animatedCard(
                title: "Aloqa maʼlumotlari",
                child: _contactInfo(),
              ),
              const SizedBox(height: 20),
              _animatedCard(
                title: "Oʻzim haqimda",
                child: _aboutMe(),
              ),
              const SizedBox(height: 20),
              _animatedCard(
                title: "Hobbilarim",
                child: _hobbyChips([
                  'Oʻyin oʻynash',
                  'Video montaj qilish',
                  'Film koʻrish',
                  'Dam olish',
                ]),
              ),
              const SizedBox(height: 20),
              _animatedCard(
                title: "Taʼlim",
                child: _educationItem(
                  title: "Bakalavr: Fargʻona Davlat Texnika Universiteti",
                  date: "2022-yil sentabrda boshlangan",
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Animatsiyali kartochka
  Widget _animatedCard({required String title, required Widget child}) {
    return TweenAnimationBuilder<double>(
      duration: const Duration(milliseconds: 600),
      tween: Tween(begin: 0.9, end: 1),
      curve: Curves.elasticOut,
      builder: (context, value, childWidget) {
        return Transform.scale(
          scale: value,
          child: childWidget,
        );
      },
      child: GestureDetector(
        onTapDown: (_) {}, // optional bosilganda effekt uchun
        child: Card(
          elevation: 8,
          shadowColor: Colors.deepPurple.withOpacity(0.4),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.deepPurple,
                  ),
                ),
                const SizedBox(height: 10),
                child,
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _contactInfo() {
    return Column(
      children: const [
        ListTile(
          leading: Icon(Icons.location_on_outlined, color: Colors.deepPurple),
          title: Text(
            "Andijon viloyati, Andijon shahri,\nMarifat M.F.Y., S. Yusupov ko'chasi, 20-uy",
            style: TextStyle(fontSize: 14),
          ),
        ),
        ListTile(
          leading: Icon(Icons.email_outlined, color: Colors.deepPurple),
          title: Text(
            "turgunboyevnazrullo@gmail.com",
            style: TextStyle(fontSize: 14),
          ),
        ),
        ListTile(
          leading: Icon(Icons.phone_outlined, color: Colors.deepPurple),
          title: Text(
            "+998 90 540 55 37",
            style: TextStyle(fontSize: 14),
          ),
        ),
      ],
    );
  }

  Widget _aboutMe() {
    return const Text(
      "Men muammolarni hal qilish va yangi ko‘nikmalarni o‘rganishni yaxshi ko‘raman. "
      "Yolg‘izlikda vaqt o‘tkazish menga o‘zim ustida ishlash uchun yordam beradi. "
      "Qiyin ishlarni bajarishni yoqtiraman, chunki ular meni rivojlantiradi.",
      style: TextStyle(fontSize: 15, height: 1.6),
    );
  }

  Widget _educationItem({required String title, required String date}) {
    return ListTile(
      leading: const Icon(Icons.school_outlined, color: Colors.deepPurple),
      title: Text(
        title,
        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
      ),
      subtitle: Text(date, style: const TextStyle(fontSize: 14)),
    );
  }

  Widget _hobbyChips(List<String> hobbies) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: hobbies.map((hobby) {
        return Chip(
          label: Text(hobby),
          labelStyle: const TextStyle(color: Colors.white),
          backgroundColor: Colors.deepPurple,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
        );
      }).toList(),
    );
  }
}
